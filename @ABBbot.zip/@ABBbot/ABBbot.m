classdef ABBbot < RobotBaseClass

    properties(Access = public)   
        plyFileNameStem = 'ABBbot';
    end
    
    
    methods
%% Constructor
        function self = ABBbot(baseTr,useTool,toolFilename)
            if nargin < 3
                if nargin == 2
                    error('If you set useTool you must pass in the toolFilename as well');
                elseif nargin == 0 % Nothing passed
                    baseTr = transl(0,0,0);  
                end             
            else % All passed in 
                self.useTool = useTool;
                toolTrData = load([toolFilename,'.mat']);
                self.toolTr = toolTrData.tool;
                self.toolFilename = [toolFilename,'.ply'];
            end
          
            self.CreateModel();
			self.model.base = self.model.base.T * baseTr;
            self.model.tool = self.toolTr;
            self.PlotAndColourRobot();
            drawnow
        end

%% CreateModel
        function CreateModel(self)
            link(1) = Link('d', 0.09, 'a', -0.035, 'alpha', 0, 'qlim', deg2rad([0 0]), 'offset', pi/2);
            % link(2) = Link('d', 0.04, 'a', 0.06, 'alpha', -pi/2, 'qlim', deg2rad([-360 360]), 'offset', pi/4);
            link(2) = Link('d', 0.15, 'a', 0.1, 'alpha', -pi/2, 'qlim', deg2rad([-360 360]), 'offset', pi);
            link(3) = Link('d', 0.05, 'a', 0, 'alpha', 0, 'qlim', deg2rad([-360 360]), 'offset', 0);
            link(4) = Link('d', 0.018, 'a', 0.18, 'alpha', 0, 'qlim', deg2rad([-360 360]), 'offset', 0);
            link(5) = Link('d', -0.007, 'a', 0.1, 'alpha', 0, 'qlim', deg2rad([-360 360]), 'offset', 0);
            link(6) = Link('d', 0, 'a', -0.17, 'alpha', pi/2, 'qlim', deg2rad([-360 360]), 'offset', pi/2);

      
            self.model = SerialLink(link,'name',self.name);            
        end  
        %% PlotAndColourRobot
% Given a robot index, add the glyphs (vertices and faces) and
% colour them in if data is available 
        function PlotAndColourRobot(self)
            mpath = strrep(which(mfilename),[mfilename '.m'],'');

            for linkIndex = 0:self.model.n
                [ faceData, vertexData, plyData{linkIndex + 1} ] = plyread([mpath,'ABBbotLink',num2str(linkIndex),'.ply'],'tri');

                self.model.faces{linkIndex + 1} = faceData;

                % Obtain the faceData for the current link and save to the
                % cell.
                self.model.faces{linkIndex+1} = faceData;

                % Obtain the vertexData for the current link and perform 
                % operations on the values depending on the link + save to 
                % the cell.
                if linkIndex == 0
                    % Use the self.baseTr variable to shift the base (Link 0) of
                    % the robot into the wanted location.
                    % First obtain rotation and position, then multiple the vertex
                    % position by the 3x3 rotation before adding the translation
                    % (position).
                    shift = false;
                    if shift
                        rot = self.baseTr(1:3, 1:3);
                        pos = self.baseTr(1:3, 4);
                        self.model.points{linkIndex+1} = (rot * vertexData(:, :)' + pos)';
                    else
                        self.model.points{linkIndex+1} = vertexData;
                    end

                else
                    % If not Link 0 (> Link 0), no work has to be done to the
                    % vertex values as the .base method moves every link from Link
                    % 1 onwards.
                    self.model.faces{linkIndex+1} = faceData;
                    self.model.points{linkIndex+1} = vertexData;
                end
            end

            % Display robot
            self.model.plot3d(zeros(1,self.model.n),'noarrow','notiles');
            if isempty(findobj(get(gca,'Children'),'Type','Light'))
                camlight
            end  
            self.model.delay = 0;

            % Try to correctly colour the arm (if colours are in ply file data)
            for linkIndex = 0:self.model.n
                handles = findobj('Tag', self.model.name);
                h = get(handles,'UserData');
                try 
                    h.link(linkIndex+1).Children.FaceVertexCData = [plyData{linkIndex+1}.vertex.red ...
                                                                  , plyData{linkIndex+1}.vertex.green ...
                                                                  , plyData{linkIndex+1}.vertex.blue]/255;
                    h.link(linkIndex+1).Children.FaceColor = 'interp';
                catch ME_1
                    disp(ME_1);
                    continue;
            
                end
                % clear all 
                 % self.PlotAndColourRobot();
            end
            % self.PlotAndColourRobot();
        end      
    end
end

