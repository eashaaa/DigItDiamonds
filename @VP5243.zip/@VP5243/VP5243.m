classdef VP5243 < RobotBaseClass


    properties(Access = public)              
        plyFileNameStem = 'VP5243';
    end
    
    methods
%% Define robot Function 
        function self = VP5243(baseTr)
			self.CreateModel();
            if nargin < 1			
				baseTr = transl(-1.5, -0.4, 0);				
            end
            self.model.base = self.model.base.T * baseTr * trotz(pi);
            
            self.PlotAndColourRobot();         
        end

%% Create the robot model
        function CreateModel(self)   
            link(1) = Link('d',0.2,'a',0,'alpha',0,'qlim', deg2rad([-160 160]), 'offset',0);
            link(2) = Link('d',0.2,'a',0,'alpha',pi/2,'qlim', deg2rad([-120 120]), 'offset', 0); %pi/2
            link(3) = Link('d',0,'a',-0.2,'alpha',0,'qlim',deg2rad([-128 136]),'offset', 0);
            link(4) = Link('d',0,'a',-0.09,'alpha',0,'qlim',deg2rad([-120 120]), 'offset',0);


            % Incorporate joint limits
            link(1).qlim = [-160 160]*pi/180;
            link(2).qlim = [-120 120]*pi/180;
            link(3).qlim = [-128 136]*pi/180;
            link(4).qlim = [-120 120]*pi/180;
           
        

            
            self.model = SerialLink(link,'name',self.name);
        end
     
    end
end